import { useEffect, useMemo, useRef, useState, type FormEvent } from 'react'
import { Document, Page, pdfjs, type DocumentProps } from 'react-pdf'
import { Maximize2, Minus, Plus, Rows3, SearchCheck } from 'lucide-react'
import { Button, IconButton, Input, Skeleton, Tooltip } from '@/components/ui'
import { useElementSize } from '@/hooks/use-element-size'
import { useViewerStore } from '@/store/use-viewer-store'
import { formatPageRange, parsePageRange } from './page-range'
import { VirtualThumbnailList } from './virtual-thumbnail-list'
import 'react-pdf/dist/Page/AnnotationLayer.css'
import 'react-pdf/dist/Page/TextLayer.css'

pdfjs.GlobalWorkerOptions.workerSrc = new URL('pdfjs-dist/build/pdf.worker.min.mjs', import.meta.url).toString()

type PdfDocumentViewerProps = {
  data: ArrayBuffer
  onDocumentReady?: (pageCount: number) => void
  onAddSelection: (thumbnailDataUrl?: string) => void
}

export function PdfDocumentViewer({ data, onDocumentReady, onAddSelection }: PdfDocumentViewerProps) {
  const {
    pageCount,
    currentPage,
    selectedPages,
    zoom,
    fitMode,
    setPageCount,
    setCurrentPage,
    selectPage,
    setSelectedPages,
    setZoom,
    setFitMode,
  } = useViewerStore()
  const [rangeInput, setRangeInput] = useState('')
  const [rangeError, setRangeError] = useState<string>()
  const previewCanvasRef = useRef<HTMLCanvasElement>(null)
  const { ref: viewportRef, width: viewportWidth, height: viewportHeight } = useElementSize<HTMLDivElement>()
  const file = useMemo(() => ({ data: new Uint8Array(data) }), [data])

  useEffect(() => setRangeInput(formatPageRange(selectedPages)), [selectedPages])

  const handleLoad: NonNullable<DocumentProps['onLoadSuccess']> = (document) => {
    setPageCount(document.numPages)
    onDocumentReady?.(document.numPages)
  }

  const applyRange = (event: FormEvent) => {
    event.preventDefault()
    const result = parsePageRange(rangeInput, pageCount)
    if (!result.valid) {
      setRangeError(result.message)
      return
    }
    setRangeError(undefined)
    setSelectedPages(result.pages)
    if (result.pages[0]) setCurrentPage(result.pages[0])
  }

  const availableWidth = Math.max(280, viewportWidth - 80)
  const pageWidth =
    fitMode === 'page'
      ? Math.min(availableWidth, Math.max(280, (viewportHeight - 80) * 0.707))
      : fitMode === 'width'
        ? availableWidth
        : availableWidth * zoom

  const addSelection = () => {
    const source = previewCanvasRef.current
    if (!source) {
      onAddSelection()
      return
    }
    const width = 120
    const height = Math.max(1, Math.round((source.height / source.width) * width))
    const thumbnail = document.createElement('canvas')
    thumbnail.width = width
    thumbnail.height = height
    thumbnail.getContext('2d')?.drawImage(source, 0, 0, width, height)
    onAddSelection(thumbnail.toDataURL('image/jpeg', 0.68))
  }

  return (
    <Document
      className="grid min-h-0 flex-1 grid-cols-[112px_1fr] sm:grid-cols-[158px_1fr]"
      error={<div className="grid place-items-center p-8 text-sm text-danger">This PDF is invalid or corrupted.</div>}
      file={file}
      loading={<div className="col-span-2 grid place-items-center p-10"><Skeleton className="aspect-[.707] w-72" /></div>}
      onLoadSuccess={handleLoad}
    >
      <aside className="flex min-h-0 flex-col border-r bg-paper">
        <div className="border-b p-2 sm:p-3">
          <p className="mb-2 text-[10px] font-bold uppercase tracking-wider text-muted">Page range</p>
          <form onSubmit={applyRange}>
            <Input
              aria-invalid={Boolean(rangeError)}
              className="h-9 px-2 text-xs"
              onChange={(event) => setRangeInput(event.target.value)}
              placeholder="1-10, 15"
              value={rangeInput}
            />
            {rangeError && <p className="mt-1 text-[10px] leading-4 text-danger">{rangeError}</p>}
            <Button className="mt-2 w-full" size="sm" type="submit" variant="secondary">
              <SearchCheck className="size-3.5" /> Apply
            </Button>
          </form>
        </div>
        <div className="min-h-0 flex-1 pt-3">
          <VirtualThumbnailList
            currentPage={currentPage}
            onSelect={selectPage}
            pageCount={pageCount}
            selectedPages={selectedPages}
          />
        </div>
      </aside>
      <main className="paper-grid relative min-h-0 overflow-auto bg-[#e8e1d6]" ref={viewportRef}>
        <div className="flex min-h-full items-start justify-center p-5 sm:p-10">
          {pageCount > 0 && (
            <Page
              canvasRef={previewCanvasRef}
              className="overflow-hidden shadow-lift"
              loading={<Skeleton className="aspect-[.707] w-[min(70vw,680px)]" />}
              pageNumber={currentPage}
              renderAnnotationLayer
              renderTextLayer
              width={pageWidth}
            />
          )}
        </div>
        <div className="sticky bottom-4 z-10 mx-auto flex w-fit flex-wrap items-center justify-center gap-1 rounded-xl border bg-surface/95 p-1.5 shadow-soft backdrop-blur">
          <Tooltip label="Zoom out"><IconButton aria-label="Zoom out" className="size-8" onClick={() => setZoom(zoom - 0.1)}><Minus className="size-4" /></IconButton></Tooltip>
          <span className="w-12 text-center text-xs font-semibold">{Math.round((fitMode === 'custom' ? zoom : 1) * 100)}%</span>
          <Tooltip label="Zoom in"><IconButton aria-label="Zoom in" className="size-8" onClick={() => setZoom(zoom + 0.1)}><Plus className="size-4" /></IconButton></Tooltip>
          <Tooltip label="Fit width"><IconButton aria-label="Fit width" className="size-8" onClick={() => setFitMode('width')}><Rows3 className="size-4" /></IconButton></Tooltip>
          <Tooltip label="Fit page"><IconButton aria-label="Fit page" className="size-8" onClick={() => setFitMode('page')}><Maximize2 className="size-4" /></IconButton></Tooltip>
          <span className="mx-1 h-5 w-px bg-line" />
          <span className="px-1 text-xs font-semibold">{currentPage} / {pageCount}</span>
          <Button className="ml-1" disabled={!selectedPages.length} onClick={addSelection} size="sm">
            <Plus className="size-4" /> Add {selectedPages.length || ''} pages
          </Button>
        </div>
      </main>
    </Document>
  )
}
