export type ExportQuality = 'screen' | 'print' | 'press'

export type WorkspacePageGroup = {
  id: string
  sourceFileId: string
  sourceName: string
  sourceSize?: string
  sourcePageCount: number
  pages: number[]
  thumbnailDataUrl?: string
  createdAt: number
}

export type GenerationResult = {
  historyId: string
  blobUrl: string
  filename: string
  pageCount: number
  durationMs: number
  bytes: number
}
