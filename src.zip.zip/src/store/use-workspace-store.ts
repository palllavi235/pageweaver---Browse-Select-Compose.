import { arrayMove } from '@dnd-kit/sortable'
import { create } from 'zustand'
import type { WorkspacePageGroup } from '@/features/composer/types'

const STORAGE_KEY = 'pageweaver:workspace:v1'
const DEFAULT_TITLE = 'Untitled composition'
const HISTORY_LIMIT = 50

type AddGroupInput = Omit<WorkspacePageGroup, 'id' | 'createdAt'>
type WorkspaceSnapshot = { title: string; groups: WorkspacePageGroup[] }
type PersistedWorkspace = {
  version: 1
  title: string
  groups: Array<Omit<WorkspacePageGroup, 'thumbnailDataUrl'>>
  isDirty: boolean
  updatedAt: number
}

type WorkspaceState = {
  composerOpen: boolean
  sidebarOpen: boolean
  title: string
  groups: WorkspacePageGroup[]
  activeGroupId: string | null
  past: WorkspaceSnapshot[]
  future: WorkspaceSnapshot[]
  isDirty: boolean
  updatedAt: number
  toggleComposer: () => void
  setComposerOpen: (open: boolean) => void
  setSidebarOpen: (open: boolean) => void
  setActiveGroupId: (id: string | null) => void
  setTitle: (title: string) => void
  addGroup: (group: AddGroupInput) => string
  removeGroup: (id: string) => void
  duplicateGroup: (id: string) => void
  updateGroupPages: (id: string, pages: number[]) => void
  reorderGroups: (activeId: string, overId: string) => void
  moveGroup: (id: string, direction: -1 | 1) => void
  clearWorkspace: () => void
  resetWorkspace: () => void
  undo: () => void
  redo: () => void
  markGenerated: () => void
}

function loadPersistedWorkspace(): Pick<WorkspaceState, 'title' | 'groups' | 'isDirty' | 'updatedAt'> {
  const fallback = { title: DEFAULT_TITLE, groups: [], isDirty: false, updatedAt: Date.now() }
  if (typeof window === 'undefined') return fallback
  try {
    const parsed = JSON.parse(localStorage.getItem(STORAGE_KEY) ?? '') as Partial<PersistedWorkspace>
    if (parsed.version !== 1 || !Array.isArray(parsed.groups)) return fallback
    return {
      title: typeof parsed.title === 'string' && parsed.title.trim() ? parsed.title : DEFAULT_TITLE,
      groups: parsed.groups as WorkspacePageGroup[],
      isDirty: Boolean(parsed.isDirty),
      updatedAt: typeof parsed.updatedAt === 'number' ? parsed.updatedAt : Date.now(),
    }
  } catch {
    return fallback
  }
}

function snapshot(state: WorkspaceState): WorkspaceSnapshot {
  return { title: state.title, groups: state.groups }
}

function commit(
  state: WorkspaceState,
  changes: Partial<Pick<WorkspaceState, 'title' | 'groups' | 'activeGroupId'>>,
) {
  return {
    ...changes,
    past: [...state.past, snapshot(state)].slice(-HISTORY_LIMIT),
    future: [],
    isDirty: true,
    updatedAt: Date.now(),
  }
}

const persisted = loadPersistedWorkspace()

export const useWorkspaceStore = create<WorkspaceState>((set) => ({
  composerOpen: false,
  sidebarOpen: false,
  title: persisted.title,
  groups: persisted.groups,
  activeGroupId: null,
  past: [],
  future: [],
  isDirty: persisted.isDirty,
  updatedAt: persisted.updatedAt,
  toggleComposer: () => set((state) => ({ composerOpen: !state.composerOpen })),
  setComposerOpen: (composerOpen) => set({ composerOpen }),
  setSidebarOpen: (sidebarOpen) => set({ sidebarOpen }),
  setActiveGroupId: (activeGroupId) => set({ activeGroupId }),
  setTitle: (title) =>
    set((state) => {
      const normalized = title.trim() || DEFAULT_TITLE
      return normalized === state.title ? state : commit(state, { title: normalized })
    }),
  addGroup: (group) => {
    const id = crypto.randomUUID()
    set((state) =>
      commit(state, {
        groups: [...state.groups, { ...group, id, createdAt: Date.now() }],
        activeGroupId: id,
      }),
    )
    return id
  },
  removeGroup: (id) =>
    set((state) =>
      commit(state, {
        groups: state.groups.filter((group) => group.id !== id),
        activeGroupId: state.activeGroupId === id ? null : state.activeGroupId,
      }),
    ),
  duplicateGroup: (id) =>
    set((state) => {
      const index = state.groups.findIndex((group) => group.id === id)
      if (index < 0) return state
      const newId = crypto.randomUUID()
      const groups = [...state.groups]
      groups.splice(index + 1, 0, {
        ...state.groups[index],
        id: newId,
        createdAt: Date.now(),
      })
      return commit(state, { groups, activeGroupId: newId })
    }),
  updateGroupPages: (id, pages) =>
    set((state) =>
      commit(state, {
        groups: state.groups.map((group) => (group.id === id ? { ...group, pages } : group)),
      }),
    ),
  reorderGroups: (activeId, overId) =>
    set((state) => {
      const oldIndex = state.groups.findIndex((group) => group.id === activeId)
      const newIndex = state.groups.findIndex((group) => group.id === overId)
      if (oldIndex < 0 || newIndex < 0 || oldIndex === newIndex) return state
      return commit(state, { groups: arrayMove(state.groups, oldIndex, newIndex), activeGroupId: activeId })
    }),
  moveGroup: (id, direction) =>
    set((state) => {
      const index = state.groups.findIndex((group) => group.id === id)
      const nextIndex = index + direction
      if (index < 0 || nextIndex < 0 || nextIndex >= state.groups.length) return state
      return commit(state, { groups: arrayMove(state.groups, index, nextIndex), activeGroupId: id })
    }),
  clearWorkspace: () =>
    set((state) => commit(state, { groups: [], activeGroupId: null })),
  resetWorkspace: () =>
    set({
      title: DEFAULT_TITLE,
      groups: [],
      activeGroupId: null,
      past: [],
      future: [],
      isDirty: false,
      updatedAt: Date.now(),
    }),
  undo: () =>
    set((state) => {
      const previous = state.past.at(-1)
      if (!previous) return state
      return {
        ...previous,
        past: state.past.slice(0, -1),
        future: [snapshot(state), ...state.future].slice(0, HISTORY_LIMIT),
        activeGroupId: null,
        isDirty: true,
        updatedAt: Date.now(),
      }
    }),
  redo: () =>
    set((state) => {
      const next = state.future[0]
      if (!next) return state
      return {
        ...next,
        past: [...state.past, snapshot(state)].slice(-HISTORY_LIMIT),
        future: state.future.slice(1),
        activeGroupId: null,
        isDirty: true,
        updatedAt: Date.now(),
      }
    }),
  markGenerated: () => set({ isDirty: false, updatedAt: Date.now() }),
}))

let persistTimer: number | undefined
useWorkspaceStore.subscribe((state, previous) => {
  if (state.updatedAt === previous.updatedAt || typeof window === 'undefined') return
  window.clearTimeout(persistTimer)
  persistTimer = window.setTimeout(() => {
    const value: PersistedWorkspace = {
      version: 1,
      title: state.title,
      groups: state.groups.map(({ thumbnailDataUrl, ...group }) => {
        void thumbnailDataUrl
        return group
      }),
      isDirty: state.isDirty,
      updatedAt: state.updatedAt,
    }
    localStorage.setItem(STORAGE_KEY, JSON.stringify(value))
  }, 120)
})
