import { create } from 'zustand'

export type ViewerFitMode = 'width' | 'page' | 'custom'

type ViewerState = {
  fileId: string | null
  pageCount: number
  currentPage: number
  selectedPages: number[]
  selectionAnchor: number | null
  zoom: number
  fitMode: ViewerFitMode
  openDocument: (fileId: string) => void
  setPageCount: (pageCount: number) => void
  setCurrentPage: (page: number) => void
  selectPage: (page: number, mode: 'single' | 'toggle' | 'range') => void
  setSelectedPages: (pages: number[]) => void
  clearSelection: () => void
  setZoom: (zoom: number) => void
  setFitMode: (fitMode: ViewerFitMode) => void
}

export const useViewerStore = create<ViewerState>((set) => ({
  fileId: null,
  pageCount: 0,
  currentPage: 1,
  selectedPages: [],
  selectionAnchor: null,
  zoom: 1,
  fitMode: 'width',
  openDocument: (fileId) =>
    set((state) =>
      state.fileId === fileId
        ? state
        : {
            fileId,
            pageCount: 0,
            currentPage: 1,
            selectedPages: [],
            selectionAnchor: null,
            zoom: 1,
            fitMode: 'width',
          },
    ),
  setPageCount: (pageCount) => set({ pageCount }),
  setCurrentPage: (currentPage) => set({ currentPage }),
  selectPage: (page, mode) =>
    set((state) => {
      if (mode === 'range' && state.selectionAnchor) {
        const start = Math.min(state.selectionAnchor, page)
        const end = Math.max(state.selectionAnchor, page)
        const range = Array.from({ length: end - start + 1 }, (_, index) => start + index)
        return { selectedPages: range, currentPage: page }
      }
      if (mode === 'toggle') {
        const selectedPages = state.selectedPages.includes(page)
          ? state.selectedPages.filter((item) => item !== page)
          : [...state.selectedPages, page].sort((a, b) => a - b)
        return { selectedPages, selectionAnchor: page, currentPage: page }
      }
      return { selectedPages: [page], selectionAnchor: page, currentPage: page }
    }),
  setSelectedPages: (selectedPages) =>
    set({
      selectedPages: [...new Set(selectedPages)].sort((a, b) => a - b),
      selectionAnchor: selectedPages.at(-1) ?? null,
    }),
  clearSelection: () => set({ selectedPages: [], selectionAnchor: null }),
  setZoom: (zoom) => set({ zoom: Math.min(2.5, Math.max(0.4, zoom)), fitMode: 'custom' }),
  setFitMode: (fitMode) => set({ fitMode }),
}))
