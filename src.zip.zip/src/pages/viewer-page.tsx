import { ChevronLeft, Download, FileWarning, RefreshCw } from 'lucide-react'
import { useEffect } from 'react'
import { useQuery } from '@tanstack/react-query'
import { Link, useLocation, useParams } from 'react-router-dom'
import { GoogleAuthButton } from '@/components/auth-button'
import { Button, EmptyState, ErrorState, IconButton, Progress, useToast } from '@/components/ui'
import { getDrivePdfMetadata, type DrivePdfFile } from '@/features/drive/drive-service'
import { PdfDocumentViewer } from '@/features/pdf/pdf-document-viewer'
import { usePdfBuffer } from '@/features/pdf/use-pdf-buffer'
import { useAuthStore } from '@/store/use-auth-store'
import { useViewerStore } from '@/store/use-viewer-store'
import { useWorkspaceStore } from '@/store/use-workspace-store'
import { useGenerationStore } from '@/store/use-generation-store'
import { formatBytes } from '@/utils/format'
import { downloadBlobUrl } from '@/utils/download'

type ViewerLocationState = { driveFile?: DrivePdfFile } | null

export function ViewerPage() {
  const { id } = useParams()
  const location = useLocation()
  const locationState = location.state as ViewerLocationState
  const authenticated = useAuthStore((state) => state.status === 'authenticated')
  const userId = useAuthStore((state) => state.session?.user.id)
  const openDocument = useViewerStore((state) => state.openDocument)
  const selectedPages = useViewerStore((state) => state.selectedPages)
  const pageCount = useViewerStore((state) => state.pageCount)
  const addGroup = useWorkspaceStore((state) => state.addGroup)
  const setComposerOpen = useWorkspaceStore((state) => state.setComposerOpen)
  const resetGeneration = useGenerationStore((state) => state.reset)
  const showToast = useToast()
  const pdf = usePdfBuffer(authenticated ? id : undefined)
  const metadata = useQuery({
    queryKey: ['drive', userId, 'file', id],
    queryFn: ({ signal }) => getDrivePdfMetadata(id!, signal),
    enabled: authenticated && Boolean(id),
    initialData: locationState?.driveFile,
    staleTime: 5 * 60_000,
  })

  useEffect(() => {
    if (id) openDocument(id)
  }, [id, openDocument])

  if (!authenticated) {
    return <div className="page-shell py-10"><EmptyState title="Sign in to open this PDF" description="PageWeaver needs read-only Drive access before it can download and display this document." action={<GoogleAuthButton />} /></div>
  }

  if (!id) return <div className="page-shell py-10"><ErrorState description="This document link is incomplete." /></div>
  const file = metadata.data
  const addSelection = (thumbnailDataUrl?: string) => {
    if (!file || !selectedPages.length) return
    addGroup({
      sourceFileId: file.id,
      sourceName: file.name,
      sourceSize: file.size,
      sourcePageCount: pageCount,
      pages: selectedPages,
      thumbnailDataUrl,
    })
    resetGeneration()
    setComposerOpen(true)
    showToast(`${selectedPages.length} pages added to your document`)
  }
  const downloadSource = () => {
    if (!pdf.data || !file) return
    const url = URL.createObjectURL(new Blob([pdf.data], { type: 'application/pdf' }))
    downloadBlobUrl(url, file.name)
    window.setTimeout(() => URL.revokeObjectURL(url), 1000)
  }

  return <div className="flex h-[calc(100vh-72px)] min-h-[620px] flex-col">
    <div className="flex min-h-16 flex-wrap items-center gap-2 border-b bg-surface px-3 py-2 sm:px-5">
      <Link to="/app/drive"><IconButton aria-label="Back to drive"><ChevronLeft className="size-5" /></IconButton></Link>
      <div className="min-w-0 flex-1"><p className="truncate text-sm font-semibold">{file?.name ?? 'Loading document…'}</p><p className="text-[11px] text-muted">{file ? formatBytes(file.size) : 'Google Drive'}</p></div>
      <span className="rounded-full bg-[#eee8dd] px-2.5 py-1 text-xs font-semibold text-muted">{selectedPages.length} selected</span>
      <IconButton aria-label="Download source PDF" disabled={!pdf.data} onClick={downloadSource}><Download className="size-4" /></IconButton>
    </div>

    {metadata.isError ? <div className="page-shell py-10"><ErrorState description={metadata.error instanceof Error ? metadata.error.message : 'The file metadata could not be loaded.'} /></div> :
      pdf.status === 'error' ? <div className="page-shell py-10"><EmptyState icon={FileWarning} title="This PDF could not be opened" description={pdf.error ?? 'Check your connection and try again.'} action={<Button onClick={() => void pdf.retry()}><RefreshCw className="size-4" /> Retry</Button>} /></div> :
        !pdf.data ? <div className="grid flex-1 place-items-center p-8"><div className="w-full max-w-sm text-center"><p className="font-display text-xl font-semibold">Downloading PDF</p><p className="mt-2 text-sm text-muted">Only this document is being downloaded.</p><Progress className="mt-5" value={pdf.progress} /><p className="mt-2 text-xs text-muted">{pdf.progress || 0}%</p></div></div> :
          <PdfDocumentViewer data={pdf.data} onAddSelection={addSelection} />}
  </div>
}
